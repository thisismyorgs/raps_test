# Catrgory constants
CATEGORY_L1 = "Category L1"
CATEGORY_L2 = "Category L2"
DEFAULT_USER_ID = "2"