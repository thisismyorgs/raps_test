from rest_framework import serializers
import pandas as pd


class BulkDataSerializer(serializers.Serializer):
    def to_representation(self, instance):
        instance = instance.rename(index=str)
        return instance.to_dict(orient='index')
