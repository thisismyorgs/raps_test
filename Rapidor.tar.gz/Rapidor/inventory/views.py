import logging
from pathlib2 import Path
import pandas as pd
import os
from random import randint

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.template.response import TemplateResponse
from django.core.files.storage import default_storage
from django.contrib.auth.models import User
from django.db.models import Avg
from django.db.models import Q

logger = logging.getLogger(__name__)
from .models import UploadDocuments, ItemDetails, Category, ParentCode
from .constants import CATEGORY_L1, CATEGORY_L2, DEFAULT_USER_ID
from Rapidor import settings
from .serializers import BulkDataSerializer

def index(request):
    return True

def upload_doc(request): 
    '''
    Method - Loads the upload docuement home page.
    '''
    if request.method == "GET":
        return render(request, "inventory/upload_document.html", locals())


def create_categoryl1(product_data):
    failed_catl1_list = []
    '''
    Method - To Create the catogory records
    '''
    # Create catogory l1
    for category_instance in product_data.items():
        try:
            if category_instance["Category L1"]:
                Category.objects.get_or_create(
                    category_type = CATEGORY_L1,
                    category_name = category_instance["Category L1"].encode('UTF-8'))
        except Exception:
            failed_catl1_list.append(category_instance)
    if not failed_catl1_list:
        return True
    else:
        return failed_catl1_list


def create_categoryl2(product_data):
    failed_catl2_list = []
    '''
    Method - To Create the catogory records
    '''
    # Create catogory l2
    for category_instance in product_data.items():
        try:
            if category_instance["Category L2"]:
                Category.objects.get_or_create(
                    category_type = CATEGORY_L1,
                    category_name = category_instance["Category L2"].encode('UTF-8'))
        except Exception:
            failed_catl2_list.append(category_instance)
    if not failed_catl2_list:
        return True
    else:
        return failed_catl2_list


def creat_parent_code(product_data):
    '''
    Method - To Create the parent code records
    '''
    failed_parent_code_list = []
    # Create parent code
    for product_instance in product_data.items():
        try:
            if type(product_instance["Parent Code"]) == bytes:
                ParentCode.objects.get_or_create(parent_code = product_instance["Parent Code"].encode('UTF-8'))
        except Exception:
            failed_parent_code_list.append(product_instance)
    return True if not failed_parent_code_list else failed_parent_code_list


def create_items(product_data):
    """
    Method - To Create the item records
    """
    failed_items_list = []

    # Create Itemdetails 
    for product_instance in product_data.items():
        try:
            item_code = product_instance["Item Code"].encode('UTF-8')
            item_name = product_instance["Item Name"].encode('UTF-8')
            cato_l1 = product_instance["Category L1"].encode('UTF-8') 
            cato_l2 = product_instance["Category L2"].encode('UTF-8')
            upc = product_instance["UPC"].encode('UTF-8')
            if type(product_instance["Parent Code"]) != float:
                parent_code = product_instance["Parent Code"].encode('UTF-8')
            else:
                parent_code = ""
            mrp_price = product_instance["MRP Price"]
            if type(product_instance["Size"]) != float:
                size = product_instance["Size"].encode('UTF-8')
            else:
                size = ""
            enabled = product_instance["Enabled"].encode('UTF-8')
            if parent_code:
                parent_code_obj = ParentCode.objects.get(parent_code=parent_code)
            else:
                parent_code_obj = ""
            if item_code:
                item_details_instance, created = ItemDetails.objects.get_or_create(
                    item_code=item_code,
                    parent_code=parent_code_obj)
                if created:
                    item_details_instance.item_name = item_name
                    item_details_instance.category_l1 = cato_l1
                    item_details_instance.category_l2 = cato_l2
                    item_details_instance.upc = upc
                    item_details_instance.mrp = mrp_price
                    item_details_instance.size = size
                    item_details_instance.enabled = enabled
                    item_details_instance.save()
        except Exception:
            failed_items_list.append(product_instance)
    if  not failed_items_list:     
         return True
    else:
        return failed_items_list       

def upload_inventorys_data(request):
    '''
    Method - Uploads the excel document,
    reads the item data using pandas library and dump to tables 
    '''
    if request.method == "POST":
        cat_list1, cat_list2 = "", ""
        failed_item_list, failed_parent_code_list = "", ""
        user_profile = User.objects.get(id=DEFAULT_USER_ID)
        if request.FILES['documents_inventory_doc'] and user_profile:
            documents_new_upload = UploadDocuments.objects.create(
                    user_profile=user_profile
                )
            documents_new_upload.documents = request.FILES['documents_inventory_doc']
            documents_new_upload.documents_type = 'data_excel'
            documents_new_upload.save()
            document_url = str(documents_new_upload.documents)
            if document_url:
                filename = 'temp_bulk_{}.xlsx'.format(randint(0,100000))
                if not Path(filename).is_file():
                    file_open = default_storage.open(document_url,'rb')
                    with open(filename, "wb") as fh:
                        fh.write(file_open.read())
                        fh.close()
                    item_data = pd.read_excel(str(filename))
                    serializer = BulkDataSerializer(item_data)
                    os.remove(filename)
                    failed_item_list = create_items(serializer.data)
                    failed_parent_code_list = creat_parent_code(serializer.data)
                    cat_list1 = create_categoryl1(serializer.data)
                    cat_list2 = create_categoryl2(serializer.data)
                    data={"data": failed_item_list+cat_list1+cat_list2+failed_parent_code_list}
                    if data:
                        return HttpResponse("UnUploaded item details,", data)
                    else:
                        return HttpResponse("Uploaded successfully.")
                else:
                    return HttpResponse("Please try again later!!")
            else:
                return HttpResponse("Uploaded succesfully.")
        else:
            return HttpResponse("Incomplete data")
    else:
        return HttpResponse("No GET method")


def find_top_most_parent(request):
    '''
    Method 
    GET - renders  the home html page. 
    POST - takes the item by it's name or code and fetches it's top most parent.
    '''
    if request.method == "GET":
        return render(request, "inventory/list_product_by_name.html", locals())
    if request.method == "POST":
        item_name = request.POST.get('item_detail', None)
        product_list = ""
        if item_name:
            item_list = ItemDetails.objects.filter(
                Q(item_name=item_name)|Q(item_code=item_name)).first
            product_list = ParentCode.objects.get(
                parent_code=item_list.parent_code)
        return render(request, "inventory/list_product_by_name.html", locals())


def sorted_items(request):
    '''
    Method
    GET - renders  the home html page.
    POST - take the item by it's name and gets a list of it's children in sorted order.
    '''
    if request.method == "GET":
        return render(request, "inventory/list_children_sorted_order.html", locals())
    if request.method == "POST":
        item_name = request.POST.get('item_detail', None)
        product_list = ""
        if item_name:
            children_list = ItemDetails.objects.filter(parent_code__parent_code=item_name)
            children_list.sort(reverse=False)
        return render(request, "inventory/list_children_sorted_order.html", locals())


def product_counts(request):
    '''
    Method - counts both enabled and disabled products and renders to the html page.
    '''
    if request.method == "GET":
        enabled_items = ItemDetails.objects.filter(enable=True).count()
        disabled_items = ItemDetails.objects.filter(enable=False).count()
        return render(request, "inventory/count_of_products.html", locals())


def display_average_product_value(request):
    '''
    Method - Calcualte the avarege mrp of products by each category.
    '''
    if request.method == "GET":
        cat_obj = Category.objects.all()
        for category_instance in cat_obj:
            category_l1_det = ItemDetails.objects.filter(
                category_l1=category_instance.category_name).aggregate(Avg('mrp'))
        for category_instance in cat_obj:
            category_l2_det = ItemDetails.objects.filter(
                category_l2=category_instance.category_name).aggregate(Avg('mrp'))
        return render(request, "inventory/avarege_product_value.html", locals())

