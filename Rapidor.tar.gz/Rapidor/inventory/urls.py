from django.urls import path
from django.conf.urls import url

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('upload_doc/', views.upload_doc, name='upload_doc'),
    path('upload_inventorys_data/', views.upload_inventorys_data, name='upload_inventorys_data'),
    path('find_parent/', views.find_top_most_parent, name='find_top_most_parent'),
    path('sorted_items/', views.sorted_items, name='sorted_items'),
    path('product_counts/', views.product_counts, name='product_counts'),
    path('display_average_product_value/', views.display_average_product_value, name='display_average_product_value'),
    ]
