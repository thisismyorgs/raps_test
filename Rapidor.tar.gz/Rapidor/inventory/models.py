from django.db import models
from django.contrib.auth.models import User


class UploadDocuments(models.Model):
    '''
    This model stores document uploaded to the local directory.
    user's profile, document's path, type and operation status.
    '''
    user_profile = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE,)
    documents = models.FileField(upload_to='uploads/')
    documents_type = models.CharField(max_length=40, blank=True)
    status = models.CharField(max_length=40, blank=True)
    created_date = models.DateTimeField(auto_now_add = True, blank=True, null=True)
    modified_date = models.DateTimeField(auto_now = True, blank=True, null=True)
    class Meta:
        app_label = 'inventory'
        managed = True

class Category(models.Model):
    '''
    Category model, stores category name and category type
    '''
    category_name = models.CharField(max_length=40, blank=True)
    category_type = models.CharField(max_length=20, blank=True)
    created_date = models.DateTimeField(auto_now_add = True, blank=True, null=True)
    modified_date = models.DateTimeField(auto_now = True, blank=True, null=True)
    class Meta:
        app_label = 'inventory'
        managed = True

class ParentCode(models.Model):
    '''
    ParentCode model, stores parent code
    '''
    parent_code = models.CharField(max_length=40, blank=True)
    created_date = models.DateTimeField(auto_now_add = True, blank=True, null=True)
    modified_date = models.DateTimeField(auto_now = True, blank=True, null=True)
    class Meta:
        app_label = 'inventory'
        managed = True

class ItemDetails(models.Model):
    '''
    ItemDetails model, stores item details
    '''
    item_code = models.CharField(max_length=40, blank=True)
    item_name = models.CharField(max_length=40, blank=True)
    category_l1 = models.CharField(max_length=40, blank=True)
    category_l2 = models.CharField(max_length=40, blank=True)
    upc = models.CharField(max_length=40, blank=True)
    parent_code = models.ForeignKey(ParentCode, null=True, blank=True, on_delete=models.CASCADE,) 
    mrp = models.IntegerField(default=0, blank=True)
    size = models.CharField(max_length=40, blank=True)
    enable = models.BooleanField(default=0)
    created_date = models.DateTimeField(auto_now_add = True, blank=True, null=True)
    modified_date = models.DateTimeField(auto_now = True, blank=True, null=True)
    class Meta:
        app_label = 'inventory'
        managed = True